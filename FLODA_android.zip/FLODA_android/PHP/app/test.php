<?php

echo ('0');

?>