<?php
    echo $_SERVER['HTTP_ACCEPT_LANGUAGE'];


?>